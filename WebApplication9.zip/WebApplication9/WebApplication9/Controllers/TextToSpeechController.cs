﻿using Amazon.Polly;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Threading.Tasks;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.TranscribeService;
using Amazon.TranscribeService.Model;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using Amazon.Polly.Model;

namespace WebApplication9.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TextToSpeechController : ControllerBase
    {
        private readonly AmazonPollyClient pollyClient;

        public TextToSpeechController()
        {
            // AWS kimlik bilgilerini ve bölgeyi burada tanımlayın.
            string awsAccessKey = "AKIAZI7Y6LTLGDCECJ6V";
            string awsSecretKey = "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";
            RegionEndpoint region = RegionEndpoint.EUWest2; // EU West (London) bölgesi kullanılacak.

            pollyClient = new AmazonPollyClient(awsAccessKey, awsSecretKey, region);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromQuery] TextToSpeechRequest request)
        {
            try
            {
                // Metni sesli söyle ve sesi döndür.
                var voiceId = VoiceId.Filiz; 
                var format = OutputFormat.Mp3; // Ses formatı (MP3 kullanılacak).

                var synthesizeSpeechRequest = new SynthesizeSpeechRequest
                {
                    Text = request.Text,
                    VoiceId = voiceId,
                    OutputFormat = format
                };

                var response = await pollyClient.SynthesizeSpeechAsync(synthesizeSpeechRequest);

                // Stream'i döndür.
                var memoryStream = new MemoryStream();
                response.AudioStream.CopyTo(memoryStream);
                memoryStream.Seek(0, SeekOrigin.Begin);

                // MP3 dosyasını bilgisayara indirme bağlantısı olarak döndür.
                return File(memoryStream, "audio/mpeg", "output.mp3");
            }
            catch (Exception ex)
            {
                // Hata durumunda hata mesajını döndür.
                return BadRequest(new { Error = ex.Message });
            }
        }
    }

    public class TextToSpeechRequest
    {
        public string Text { get; set; }
    }
}