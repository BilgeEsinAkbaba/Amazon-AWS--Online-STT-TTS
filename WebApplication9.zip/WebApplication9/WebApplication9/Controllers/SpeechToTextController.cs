﻿using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Transfer;
using Amazon.TranscribeService;
using Amazon.TranscribeService.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using NAudio.Wave;

namespace WebApplication9.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpeechToTextController : ControllerBase
    {
        private const string accessKey = "AKIAZI7Y6LTLGDCECJ6V";
        private const string secretKey = "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";
        private const string regionName = "eu-west-2";
        private const string bucketName = "amazondepo"; // S3 depolama kovası adı

        private string GenerateJobName()
        {
            return "TranscriptionJob_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
        }

        private string ConvertToWav(string filePath)
        {
            var outputWavPath = Path.ChangeExtension(filePath, ".wav");

            using (var reader = new MediaFoundationReader(filePath))
            {
                WaveFileWriter.CreateWaveFile(outputWavPath, reader);
            }

            return outputWavPath;
        }

        [HttpPost("Transcribe")]
        public async Task<IActionResult> ConvertSpeechToText(IFormFile audioFile)
        {
            try
            {
                // Dosyayı geçici bir konuma kaydedin (örn. temp klasörü)
                string tempFilePath = Path.GetTempFileName();
                using (var stream = new FileStream(tempFilePath, FileMode.Create))
                {
                    await audioFile.CopyToAsync(stream);
                }

                // WAV formatına dönüştürün
                string wavFilePath = ConvertToWav(tempFilePath);

                // Dosyayı S3'ye yükleyin
                var s3Client = new AmazonS3Client(accessKey, secretKey, RegionEndpoint.GetBySystemName(regionName));
                var fileTransferUtility = new TransferUtility(s3Client);
                var s3Key = "audio-files/" + Path.GetFileName(wavFilePath); // S3'deki anahtar adı
                await fileTransferUtility.UploadAsync(wavFilePath, bucketName, s3Key);

                // S3 URL'sini oluşturun
                string s3Url = $"https://{bucketName}.s3.{regionName}.amazonaws.com/{s3Key}";

                AmazonTranscribeServiceClient transcribeClient = new AmazonTranscribeServiceClient(accessKey, secretKey, RegionEndpoint.GetBySystemName(regionName));

                // Amazon Transcribe'ı kullanarak sesi metne dönüştür
                StartTranscriptionJobRequest transcriptionRequest = new StartTranscriptionJobRequest
                {
                    TranscriptionJobName = GenerateJobName(), // Benzersiz bir job name oluştur
                    LanguageCode = LanguageCode.TrTR, // Türkçe dil kodunu kullanın
                    MediaFormat = MediaFormat.Wav, // WAV formatını kullanın
                    Media = new Media { MediaFileUri = s3Url } // S3 URL'sini kullanın
                };

                StartTranscriptionJobResponse transcriptionResponse = await transcribeClient.StartTranscriptionJobAsync(transcriptionRequest);

                // İşlemin tamamlanmasını bekleyin
                while (true)
                {
                    var getTranscriptionRequest = new GetTranscriptionJobRequest
                    {
                        TranscriptionJobName = transcriptionResponse.TranscriptionJob.TranscriptionJobName
                    };
                    var getTranscriptionResponse = await transcribeClient.GetTranscriptionJobAsync(getTranscriptionRequest);

                    if (getTranscriptionResponse.TranscriptionJob.TranscriptionJobStatus == TranscriptionJobStatus.COMPLETED)
                    {
                        // Metni al
                        string transcriptFileUri = getTranscriptionResponse.TranscriptionJob.Transcript.TranscriptFileUri;
                        string transcriptJson = new WebClient().DownloadString(transcriptFileUri);
                        JObject json = JObject.Parse(transcriptJson);
                        string transcript = json["results"]["transcripts"][0]["transcript"].ToString();

                        // Başarılı durumda metni döndürün
                        var result = new { TranscriptionResult = "Ses başarıyla metne dönüştürüldü.", Transcript = transcript };
                        return Ok(result);
                    }

                    // İşlem henüz tamamlanmamışsa, bir süre bekleyin ve tekrar kontrol edin.
                    await Task.Delay(5000); // 5 saniye bekle (isteğe bağlı olarak ayarlayabilirsiniz)
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda hata mesajını döndürün
                var error = new { ErrorMessage = "Hata: " + ex.Message };
                return BadRequest(error);
            }
        }
    }
}
